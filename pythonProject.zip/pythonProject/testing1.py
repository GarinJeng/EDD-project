from pyfirmata import Arduino, util
import time

board = Arduino('COM3')
it = util.Iterator(board)
it.start()

# Explicitly set the pin mode for analog pin A0
board.analog[0].enable_reporting()

# Allow some time for data to start reporting correctly
time.sleep(1)

# Attempt to read the analog value
analog_value = board.analog[0].read()
if analog_value is not None:
    print('Analog value:', analog_value)
else:
    print('No analog value received yet.')

# Keep the script running to listen for more values
try:
    while True:
        time.sleep(1)
        current_value = board.analog[0].read()
        if current_value is not None:
            print('Continuous Analog value:', current_value)
except KeyboardInterrupt:
    print("Exiting")
