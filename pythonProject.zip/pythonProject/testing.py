import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QPushButton
from pyfirmata import Arduino, util

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Arduino Data Reader")
        self.setGeometry(100, 100, 300, 200)

        self.button = QPushButton("Read Data", self)
        self.button.setGeometry(100, 50, 100, 50)
        self.button.clicked.connect(self.read_data)

        self.arduino = Arduino('COM3')  # Change 'COM3' to your Arduino port
        self.iterator = util.Iterator(self.arduino)
        self.iterator.start()

    def read_data(self):
        analog_value = self.arduino.analog[0].read()
        if analog_value is not None:
            print("Analog Pin A0: ", analog_value)
        else:
            print("Failed to read analog pin A0")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())
